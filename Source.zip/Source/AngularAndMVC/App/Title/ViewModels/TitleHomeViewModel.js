﻿titleModule.controller("titleHomeViewModel", function ($scope, titleService, $http, $q, $routeParams, $window, $location, viewModelHelper) {

    $scope.viewModelHelper = viewModelHelper;
    $scope.titleService = titleService;


    var initialize = function () {

    }

    initialize();
});

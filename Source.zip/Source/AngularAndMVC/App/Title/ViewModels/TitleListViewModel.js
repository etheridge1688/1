﻿titleModule.controller("titleListViewModel", function ($scope, titleService, $http, $q, $routeParams, $window, $location, viewModelHelper) {

    $scope.viewModelHelper = viewModelHelper;
    $scope.titleService = titleService;

    var initialize = function () {
        $scope.refreshTitles();
    }

    $scope.refreshTitles = function () {
        viewModelHelper.apiGet('api/titles', null,
            function (result) {
                $scope.titles = result.data;
            });
    }

    $scope.showTitle = function (title) {
        $scope.flags.shownFromList = true;
        viewModelHelper.navigateTo('title/show/' + title.TitleId);
    }

    initialize();
});

﻿titleModule.controller("titleViewModel", function ($scope, titleService, $http, $q, $routeParams, $window, $location, viewModelHelper) {

    $scope.viewModelHelper = viewModelHelper;
    $scope.titleService = titleService;

    var initialize = function () {
        $scope.refreshTitle($routeParams.titleId);
    }

    $scope.refreshTitle = function (titleId) {
        viewModelHelper.apiGet('api/title/' + titleId, null,
            function (result) {
                titleService.titleId = titleId;
                $scope.title = result.data;
            });
    }

    initialize();
});

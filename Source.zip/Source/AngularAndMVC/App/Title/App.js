﻿
var titleModule = angular.module('title', ['common'])
    .config(function ($routeProvider, $locationProvider) {
        $routeProvider.when('/title', { templateUrl: '/App/Title/Views/TitleHomeView.html', controller: 'titleHomeViewModel' });
        $routeProvider.when('/title/list', { templateUrl: '/App/Title/Views/TitleListView.html', controller: 'titleListViewModel' });
        $routeProvider.when('/title/show/:titleId', { templateUrl: '/App/Title/Views/TitleView.html', controller: 'titleViewModel' });
        $routeProvider.otherwise({ redirectTo: '/title' });
        $locationProvider.html5Mode({
            enabled: true,
            requireBase: false
        });
    });

titleModule.factory('titleService', function ($rootScope, $http, $q, $location, viewModelHelper) { return MyApp.titleService($rootScope, $http, $q, $location, viewModelHelper); });

(function (myApp) {
    var titleService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;

        self.titleId = 0;

        return this;
    };
    myApp.titleService = titleService;
}(window.MyApp));

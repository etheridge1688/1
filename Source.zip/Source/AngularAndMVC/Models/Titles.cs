﻿//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace AngularAndMVC.Models
//{
//    public class TitleModel
//    {
//        public int TitleId { get; set; }
//        public string TitleName { get; set; }
//        //public string LastName { get; set; }
//        //public string Email { get; set; }
//    }
//}
using System;
using System.Collections.Generic;
using System.Linq;

namespace AngularAndMVC.Models
{
    public class TitleModel
    {
        public int TitleId { get; set; }
        public string TitleName { get; set; }
        //public decimal UnitPrice { get; set; }
    }

    public class TitleDetailModel
    {
        public int TitleId { get; set; }
        public string TitleName { get; set; }
        //public decimal UnitPrice { get; set; }
    }

}
using System;
using System.Collections.Generic;
using System.Linq;

namespace AngularAndMVC.Models
{
    public static class DataFactory
    {
        public static IEnumerable<TitleModel> GetTitles()
        {
            List<TitleModel> lstTitles = new List<TitleModel>();
            TitlesEntities te1 = new TitlesEntities();
            //var vTest = te1.Titles.ToList<int TitleId, Description , string>(c => c.TitleId == 610);

            //lstTitles.Add(vTest.TitleName)
            var query = (from t in te1.Titles
                        orderby t.TitleName
                        select new
                        { TitleID = t.TitleId,
                            TitleName = t.TitleName }).ToList(); ;
            var v = query.ToList(); //[0].ToString();
            //List<TitleModel>  v = query.ToList<TitleModel>();
            //lstTitles = v.ToList<TitleModel>();
            //lstTitles = query.ToList();

            var query1 = query.Where(t => t.TitleName.Contains("the"));

            //v.IndexOf(0);
            //return query1.ToString(); // TitleName.ToList();

            for (int i = 0; i < v.Count; i++)
            {
                TitleModel tm = new TitleModel()
                {
                    TitleId = v[i].TitleID,
                    TitleName = v[i].TitleName
                };
                lstTitles.Add(tm);
            }

            return lstTitles;
            
        }

        /*  
         *   Code for searching keywords for movie titles
         *   
         *           TitlesEntities1 te1 = new TitlesEntities1();
            var vTest = te1.Titles.FirstOrDefault(c => c.TitleId == 610);

            var query = from t in te1.Titles
                        orderby t.TitleName
                        select new
                        { TitleName = t.TitleName};


            //if (!String.IsNullOrEmpty(sLastName))
            string strName1 = "The";
            string strName2 = "2";
            var    query1 = query.Where(t => t.TitleName.Contains(strName1));

            var query2 = ((from t1 in te1.Titles
                           where t1.TitleName.Contains(strName1)
                           select t1.TitleName)
                          .Union(from t2 in te1.Titles
                                 where t2.TitleName.Contains(strName2)
                                 select t2.TitleName
                        ));

         * 
         *  
         */


    }
}

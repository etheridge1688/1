﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AngularAndMVC.Models;

namespace AngularAndMVC.Controllers.API
{
    [RoutePrefix("api")]
    public class DataApiController : ApiController
    {
        [HttpGet]
        [Route("titles")]
        public HttpResponseMessage GetTitles(HttpRequestMessage request)
        {
            var titles = DataFactory.GetTitles();

            return request.CreateResponse<TitleModel[]>(HttpStatusCode.OK, titles.ToArray());
        }

        [HttpGet]
        [Route("title/{titleId}")]
        public HttpResponseMessage GetTitle(HttpRequestMessage request, int titleId)
        {
            var titles = DataFactory.GetTitles();
            var title = titles.FirstOrDefault(item => item.TitleId == titleId);

            return request.CreateResponse<TitleModel>(HttpStatusCode.OK, title);
        }

        
    }
}
